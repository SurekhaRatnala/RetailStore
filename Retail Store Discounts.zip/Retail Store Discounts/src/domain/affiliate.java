package domain;

public class affiliate extends Customer {
	
	public final Double discount = 10.00;

	

}
