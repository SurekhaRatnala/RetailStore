package domain;

import java.util.ArrayList;
import java.util.List;

public class Customer {

	public Double discountPercent = 0.00;
	
	private Integer id;
	
	private Integer since;
	
	private List<Items> listOfItems = new ArrayList<>();
	
	public Customer(){
		
	}
	
	public Customer(Integer id, Integer months){
		this.id = id;
		this.since = months;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getSince() {
		return since;
	}

	public void setSince(Integer since) {
		this.since = since;
	}

	public List<Items> getListOfItems() {
		return listOfItems;
	}

	public void setListOfItems(List<Items> listOfItems) {
		this.listOfItems = listOfItems;
	}

	public Double customerSince(){
		if(this.since > 36)
			discountPercent = 5.00;
		return discountPercent;
			
	}
}
