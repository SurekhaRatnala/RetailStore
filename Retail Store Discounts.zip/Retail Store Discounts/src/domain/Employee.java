package domain;

public class Employee extends Customer {

	public final Double discount = 30.00;
}
