package utility;

public enum ItemsListWithPrices {
	
	ITEM1(1,100.00),
	ITEM2(2,150.00),
	ITEM3(3,100.00),
	ITEM4(4,100.00),
	ITEM5(5,100.00),
	ITEM6(6,100.00),
	ITEM7(7,100.00),
	Grocery1(1,10.00),
	Grocery2(2,10.00),
	Grocery3(3,10.00);
		
	ItemsListWithPrices(Integer itemId,Double price){
		this.itemId = itemId;
		this.price = price;
	}
	
	private final Integer itemId;
	
	private final Double price;

	public Integer getItemId() {
		return itemId;
	}

	public Double getPrice() {
		return price;
	}
}
