package Main;

import java.util.ArrayList;
import java.util.Scanner;

import domain.Customer;
import domain.Items;

public class Purchase {
	public static void main(String args[]){
		while(true){
			System.out.println("Welcome to Retail Store!!");
			System.out.println("Pleae input value based on below selection!!");
			System.out.println("1. New Customer");
			System.out.println("2. Exit");
			try(Scanner s = new Scanner(System.in)){
			//Scanner s = new Scanner(System.in);
			switch(s.nextInt()){
				case 1: System.out.println("Enter Customer ID:");
						Customer c = new Customer();
						c.setId(new Scanner(System.in).nextInt());
						System.out.println("Enter Items:");
						/*while(true){
						switch(s.nextInt()){
						case 
						ArrayList<Items> items = new ArrayList<>();
						Items i = new Items();
						i.setItemId(new Scanner(System.in).nextInt());
						items.add(i);
						}
						}*/
						continue;
						
				case 2: s.close();
						System.exit(0);
			}
		}catch(Exception e){
			e.printStackTrace();
			System.exit(0);
		}
		
	}
		
		
		
		
	}
}
